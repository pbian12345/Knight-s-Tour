#include "knight_tracker.h"

knight_tracker::knight_tracker()
{
    current_x = 1;
    current_y = 0;
    current_count = 0;
}
void knight_tracker::show_label(){

}

void knight_tracker::hide_label(){

}
coord_node* knight_tracker::return_coordinates(int i){
    return array[i];
}
void knight_tracker::add_newcoord(int x, int y){
    coord_node *test = new coord_node(x,y);
    array[current_count] = test;
    current_count++;
}

