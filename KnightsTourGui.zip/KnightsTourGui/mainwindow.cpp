#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    knights_tour();
    ui->setupUi(this);
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::knights_tour(){
    Tour test1(4, 4);
    test1.printBoard();

    bool is_done = false;
    while (!is_done){
//        test1.possibles();
        if(!test1.get_have_bted()){
            test1.possibles();
        }
        // Chain rule function call, isnull is a set of a possibilities on
        is_done = test1.run_check(test1.search());
    }
    cout << "Successful tour!" << endl;
//    test1.printBoard();
    cout << endl << "======================Printing path========================" << endl;
    test1.normal_print();
    obj = test1.return_obj();

//    Tour test1(1, 0);
//    myqueue::myQueue<int*> path_temp;
//    obj.add_newcoord(1,0);

//    for(int i = 0; i < 63; ++i){
//        // First it calls the possibles function and generates all given possibilities from that point
//        // Stores possibilities into a vector of int pointers
//        // Returns vector to the search function
////        test1.possibles_stack();
////        test1.stack_push(test1.searchStack());
//        test1.q_enqueue(test1.search(test1.possibles()));
//        obj.add_newcoord(test1.getXPosition(),test1.getYPosition());
//    }

}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::setupUI()
{

}

string MainWindow::arrayactivation(int x, int y){
    int size = 8;
    // Note: Coordinates are (a-h,0-7)

    string str = "";
    string second = "";
    ss << y;
    ss >> second;
    for (char letter = 'a'; letter < 'i'; letter++){
        for (int j = 0; j < size; j++){
            if (x == letter - 97 && j == y){
                str += letter;
                str += second;
                break;
            }
        }
    }
    ss.clear();
    return str;
}
char MainWindow::switchcase(int x, knight_tracker *obj){

    switch(x){

    case 0:
        break;
    case 1:
        break;

    case 2:
        break;

    case 3:
        break;

    case 4:
        break;

    case 5:
        break;

    case 6:
        break;

    case 7:
        break;

    }

}

void MainWindow::moves(QString x)
{
    QList<QLabel *> labels = ui->boardwidget_2->findChildren<QLabel *>(QRegExp(x));

    if (x != ""){
        foreach(QLabel *l, labels)
        {
          l->show();
        }
    }
}

void MainWindow::initialize()
{
    coord_node* point;
    string temp = "";
    int temp_x, temp_y;
    // Note: Coordinates are (a-h,0-7)
    for (int i = 0; i < 63; i++){
        point = (obj.return_coordinates(i));
        temp_x = point->x;
        temp_y = point->y;
        cout << "TEMP_X: " << temp_x << endl;
        cout << "TEMP_Y: " << temp_y << endl;
        coordi[i] = arrayactivation(temp_x,temp_y);
        cout << "COORDI B: " << coordi[i] << endl;
    }

}

void MainWindow::hide(){

    QList<QLabel*> list = ui->boardwidget_2->findChildren<QLabel*>();
    foreach(QLabel *l, list)
    {
            l->hide();
    }
    ui->board_3->show();
}

void MainWindow::setupSignalsSlots()
{
//    connect(ui->pushButton,SIGNAL(clicked(bool)),this,SLOT(clickButton1()));
}

void MainWindow::on_pushButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
    hide();
    initialize();
}


void MainWindow::on_pushButton_2_clicked()
{
    if (clicks < 64){
        moves(QString::fromStdString(coordi[clicks]));
        clicks++;
    }
    else {
        ui->stackedWidget->setCurrentIndex(2);
    }
}
