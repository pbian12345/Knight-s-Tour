#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QWidget>
#include <QStringList>
#include <QDebug>
#include <string>
#include <iostream>
#include <QTextStream>
#include <QMessageBox>
#include "knight_tracker.h"
#include <sstream>
#include <QApplication>
#include "tour.h"
#include "priorityqueue.h"
#include "windows.h"

using namespace std;
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    void setupSignalsSlots();
    void setupUI();
    string arrayactivation(int x, int y);
    void initialize();
    void moves(QString x);
    int array[7];
    void coordinates();
    void hide();
    char switchcase(int x, knight_tracker *obj);
    void knights_tour();

    ~MainWindow();

private:
    Ui::MainWindow *ui;
    int clicks = 0;
    QString temp;
    stringstream ss;
    knight_tracker obj;
    int current_x;
    int current_y;
    string coordi[64];

private slots:
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
};

#endif // MAINWINDOW_H
