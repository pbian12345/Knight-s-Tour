#ifndef KNIGHT_TRACKER_H
#define KNIGHT_TRACKER_H

struct coord_node {
    int x;
    int y;

    coord_node(){
        x = 0;
        y = 0;
    }

    coord_node(int x_in, int y_in){
        x = x_in;
        y = y_in;
    }
};

class knight_tracker
{
public:
    knight_tracker();
    coord_node get_coordinates();
    void add_newcoord(int x, int y);
    void show_label();
    void hide_label();
    void addY(int y);
    void add(int x);
    void switchcase(int x);
    coord_node* return_coordinates(int i);
private:
    coord_node* array[64];
    coord_node* p;
    knight_tracker *obj;
    int current_count;
    int current_x;
    int current_y;
};

#endif // KNIGHT_TRACKER_H
